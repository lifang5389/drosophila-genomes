Created by:  John W. Cain, June 2020

Here is an explanation of the files in this directory, and how to use the code.    

1) The Excel spreadsheet file 20200615_Droso_N_genes.xlsm contains one tab for each of the 47 drosophila species.
Each tab contains five columns:  phylostratum number; mean age (this column isn't used); phylostratum midpoint;  
phylostratum duration, and number of proteins.

2) The file 25.txt in this directory is a plain text file containing the D. melanogaster data from the Excel spreadsheet.
This file is in a tab delimited .txt format.  To perform the data fits for one of the other species, simply pick one
from the Excel spreadsheet, export the data as tab-delimited plain text and overwrite the 25.txt file.

3) Make sure that the freely available program "gnuplot" is installed on your computer, and that a C++ compiler is
installed as well.  Then, compile and run the C++ program create.C.
Running "create" will read in the 25.txt file, strip out the data from relevant columns, and execute
gnuplot fitscript to [attempt to] get the best fit parameters for each type of plot.  Then, the ./create program
will auto-generate the myplot file, and run "gnuplot myplot" to auto-generate the figures.

Note that gnuplot implements the Marquardt-Levenberg algorithm to generate curves of best fit.
