#include <iostream>
#include <fstream>
#include <cmath>
#include <cstdlib>

using namespace std;

ofstream ofs1("proteins-PSmidpoint.txt");               //proteins versus PSmidpoint
ofstream ofs2("proteins-PSduration.txt");               //proteins versus PSduration
ofstream ofs3("proteinsoverduration-PSmidpoint.txt");   //(proteins/PSduration) versus PSmidpoint
ofstream ofsplot("myplot");

int main() {

  ofsplot << "set terminal postscript eps enhanced color font \"Helvetica,32\"" << endl;
  ofsplot << "set nokey" << endl;
  ofsplot << "set xrange[0:4500]" << endl;
  ofsplot << "set yrange[0:6500]" << endl;
  ofsplot << "set xtics(0,1000,2000,3000,4000)" << endl;
  ofsplot << "set ytics(0,1500,3000,4500,6000)" << endl;

  ifstream indata("./25.txt");
  string firstcolumn;
  double col[6];       //I'm not using col[0] or col[1] in my arrays below;
  double ratio;

  indata >> firstcolumn >> col[2] >> col[3] >> col[4] >> col[5];   

  while (!indata.eof()) {

    ratio = col[5]/col[4];
    ofs1 << col[3] << "\t" << col[5] << endl;
    ofs2 << col[4] << "\t" << col[5] << endl;
    ofs3 << col[3] << "\t" << ratio  << endl;

    indata >> firstcolumn >> col[2] >> col[3] >> col[4] >> col[5];   

  }  

  cout << "Press any key to run the data fitting...";
  cin.get();
  
  
  //  system ("gnuplot fitscript");
  system ("/Applications/Gnuplot.app/Contents/Resources/bin/gnuplot fitscript");
    
  cout << "Data fitting complete.  Press any key to continue...";
  cin.get();

  ifstream inPSmid("PSmid.txt");
  for (std::string str; std::getline(inPSmid, str); ) {
    ofsplot << str << endl;
  }
  
  ofsplot << "set xlabel 'PS Midpoint (Mya)'" << endl;
  ofsplot << "set ylabel 'Proteins (200k hit limit)'" << endl;
  ofsplot << "set output \"proteins-PSmidpoint.eps\"" << endl;
  ofsplot << "plot 'proteins-PSmidpoint.txt' with points pointsize 1.5 pointtype 5, a25*exp(-b25*x)+c25*exp(d25*x) with lines lw 5 lt 1" << endl;

  ofsplot << endl << "reset" << endl;
  ofsplot << "set nokey" << endl;
  ofsplot << "set xrange[0:800]" << endl;
  ofsplot << "set yrange[100:300]" << endl;
  ofsplot << "set xtics(0,200,400,600,800)" << endl;
  ofsplot << "set ytics(100,150,200,250,300)" << endl;
  ofsplot << "set xlabel 'PS Midpoint (Mya)'" << endl;
  ofsplot << "set ylabel 'Proteins (200k hit limit)'" << endl;
  ofsplot << "set output \"proteins-PSmidpoint-zoom.eps\"" << endl;
  ofsplot << "plot a25*exp(-b25*x)+c25*exp(d25*x) with lines lw 5 lt 1" << endl;
  ofsplot << endl << "#---------------------------------------------------------------------------------------------" << endl << endl;


  ofsplot << endl << "reset" << endl;
  ofsplot << "set nokey" << endl;
  ofsplot << "set xrange[0:2000]" << endl;
  ofsplot << "set yrange[0:2000]" << endl;
  ofsplot << "set xtics(0,500,1000,1500,2000)" << endl;
  ofsplot << "set ytics(0,500,1000,1500,2000)" << endl;
  ofsplot << "set xlabel 'PS Duration (Mya)'" << endl;
  ofsplot << "set ylabel 'Proteins (200k hit limit)'" << endl;
  ofsplot << "set output \"proteins-PSduration.eps\"" << endl;

  ifstream inPSdur("PSdur.txt");
  for (std::string str; std::getline(inPSdur, str); ) {
    ofsplot << str << endl;
  }

  ofsplot << "plot 'proteins-PSduration.txt' with points pointsize 1.5 pointtype 5, m25*x+b25 with lines lw 5 lt 1" << endl;
  ofsplot << endl << "#---------------------------------------------------------------------------------------------" << endl << endl;


  ofsplot << endl << "reset" << endl;
  ofsplot << "set nokey" << endl;
  ofsplot << "set xrange[0:4500]" << endl;
  ofsplot << "set yrange[0:35]" << endl;
  ofsplot << "set xtics(0,1000,2000,3000,4000)" << endl;
  ofsplot << "set ytics(0,10,20,30)" << endl;
  ofsplot << "set xlabel 'PS Midpoint (Mya)'" << endl;
  ofsplot << "set ylabel 'Proteins/PS Duration'" << endl;
  ofsplot << "set output \"proteinsoverduration-PSmidpoint.eps\"" << endl;

  ifstream inPSratio("PSratio.txt");
  for (std::string str; std::getline(inPSratio, str); ) {
    ofsplot << str << endl;  
  }

  ofsplot << "plot 'proteinsoverduration-PSmidpoint.txt' with points pointsize 1.5 pointtype 5, a25*exp(-1.0*b25*x)+c25*exp(d25*x) with lines lw 5 lt 1" << endl;

  ofsplot << endl << "reset" << endl;
  ofsplot << "set nokey" << endl;
  ofsplot << "set xrange[0:800]" << endl;
  ofsplot << "set yrange[0:35]" << endl;
  ofsplot << "set xtics(0,200,400,600,800)" << endl;
  ofsplot << "set ytics(0,10,20,30)" << endl;
  ofsplot << "set xlabel 'PS Midpoint (Mya)'" << endl;
  ofsplot << "set ylabel 'Proteins/PS Duration'" << endl;
  ofsplot << "set output \"proteinsoverduration-PSmidpoint-zoom.eps\"" << endl;
  ofsplot << "plot a25*exp(-1.0*b25*x)+c25*exp(d25*x) with lines lw 5 lt 1" << endl;


  cout << "Figures generated.  Press any key to display the figures...";
  cin.get();
  

  //system ("gnuplot myplot");
  //system ("evince ./*.eps &");
  system ("/Applications/Gnuplot.app/Contents/Resources/bin/gnuplot myplot");
  system ("open ./*.eps &");


  return 0;

}
